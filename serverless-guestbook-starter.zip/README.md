# Cloud Guestbook — AWS Student Community Day

90-minute instructor-led workshop: AWS Amplify Hosting + Lambda Function URL + Amazon DynamoDB + IAM.

## Download and host the student guide
- Open `student-lab.html` in a web browser, or host it together with the ZIP files on a static website.
- `frontend-deploy.zip` contains four files for the Amplify deployment. Students must unzip it, edit `config.js`, and re-zip all four files at root level before deploying.
- `serverless-guestbook-starter.zip` includes backend, frontend and documentation.

## Important notes
- Create DynamoDB table `StudentGuestbook` with partition key `messageId` (String).
- Create Lambda function `student-guestbook-api` using Python and paste `backend/lambda_function.py`.
- The IAM inline policy is scoped to the specific DynamoDB table ARN, replace the placeholder.
- Function URL must have CORS enabled for GET, POST, and `Content-Type` header. For a temporary classroom demo use auth type NONE only in learning accounts. AWS organization policies may prevent public Function URLs.
- The sample uses Scan for small classroom demos only (not suitable for scalable production traffic).
- Limit access, avoid personal data, and clean up all services.
- This is intentionally not production-ready: no user authentication, abuse protection, WAF, or throughput controls. Consider API Gateway, Cognito and stronger controls in a production extension.
- Account eligibility for promotional credits varies; confirm redemption rules in Billing.

## Cleanup
Delete Amplify app, Lambda function, DynamoDB table. Review CloudWatch log groups and Billing.

## Publishing to GitHub
Create a public GitHub repository called `aws-student-serverless-guestbook`, commit the contents of this folder (or just `frontend`, `backend`, `README.md`, and `student-lab.html`), and use your GitHub repository URL for the student handout. No GitHub repository has been published automatically.
