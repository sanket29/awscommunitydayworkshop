import json
import os
import uuid
from datetime import datetime, timezone
import boto3

TABLE_NAME = os.environ.get('TABLE_NAME', 'StudentGuestbook')
table = boto3.resource('dynamodb').Table(TABLE_NAME)

def respond(status, payload):
    return {'statusCode': status, 'headers': {'Content-Type': 'application/json'}, 'body': json.dumps(payload)}

def lambda_handler(event, context):
    method = event.get('requestContext', {}).get('http', {}).get('method', 'GET')
    try:
        if method == 'GET':
            result = table.scan(Limit=50)
            messages = sorted(result.get('Items', []), key=lambda x: x.get('createdAt', ''), reverse=True)
            return respond(200, {'messages': messages})
        if method == 'POST':
            data = json.loads(event.get('body') or '{}')
            name = str(data.get('name', '')).strip()
            message = str(data.get('message', '')).strip()
            if not (1 <= len(name) <= 30 and 1 <= len(message) <= 240):
                return respond(400, {'error': 'Nickname must be 1–30 characters and message 1–240 characters.'})
            item = {'messageId': str(uuid.uuid4()), 'name': name, 'message': message,
                    'createdAt': datetime.now(timezone.utc).isoformat()}
            table.put_item(Item=item)
            return respond(201, {'ok': True, 'messageId': item['messageId']})
        return respond(405, {'error': 'Method not allowed'})
    except (ValueError, TypeError):
        return respond(400, {'error': 'Invalid JSON request'})
    except Exception as err:
        print('Request failed:', str(err))
        return respond(500, {'error': 'Backend error; check Lambda logs'})
